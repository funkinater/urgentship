'use client';

import {
  FaInfoCircle,
  FaBoxOpen,
  FaWarehouse,
  FaTruck,
  FaCheckCircle,
  FaTimes,
} from 'react-icons/fa';

const statuses = [
  { id: 'Shipping Information Received', icon: FaInfoCircle },
  { id: 'Picked up', icon: FaBoxOpen },
  { id: 'Checked in', icon: FaWarehouse },
  { id: 'Out for Delivery', icon: FaTruck },
  { id: 'Delivered', icon: FaCheckCircle },
];

const statusOrder = statuses.map((s) => s.id.toLowerCase());

interface TrackingProgressProps {
  currentStatus: string;
}

export default function TrackingProgress({ currentStatus }: TrackingProgressProps) {
  const normalizedStatus = currentStatus.toLowerCase();
  const currentIndex =
    normalizedStatus === 'exception' || normalizedStatus === 'returned'
      ? 3.5
      : statusOrder.indexOf(normalizedStatus);
  const isException = currentIndex === 3.5;

  return (
    <div className="py-12 bg-gradient-to-br from-blue-50 via-white to-blue-100">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h2 className="text-xl font-semibold mb-8 text-gray-800">Tracking Progress</h2>
        <div className="flex items-center justify-between gap-0 relative">
          {statuses.map((step, index) => {
            const isActive = index <= currentIndex;
            const Icon = step.icon;

            return (
              <div key={step.id} className="flex-1 flex items-center relative z-10">
                {/* Step Icon */}
                <div className="flex flex-col items-center w-full">
                  <div
                    className={`flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-300 ${
                      isActive
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-gray-200 border-gray-300 text-gray-500'
                    }`}
                  >
                    <Icon size={20} />
                  </div>
                  <p
                    className={`text-xs mt-2 ${
                      isActive ? 'text-gray-800 font-medium' : 'text-gray-400'
                    }`}
                  >
                    {step.id}
                  </p>
                </div>

                {/* Connector line */}
                {index < statuses.length - 1 && (
                  <div
                    className={`absolute top-6 left-1/2 w-full h-1 z-0 transition-colors duration-300 ${
                      index < currentIndex ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  ></div>
                )}

                {/* Exception marker inserted between step 3 and 4 */}
                {isException && index === 3 && (
                  <div className="absolute -right-[6%] top-0 z-20 flex flex-col items-center text-red-600 text-xs">
                    <div className="w-8 h-8 rounded-full border-2 border-red-600 flex items-center justify-center bg-red-100 shadow-md">
                      <FaTimes className="text-red-600" />
                    </div>
                    <span className="mt-1 text-[10px] font-semibold">Exception</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
